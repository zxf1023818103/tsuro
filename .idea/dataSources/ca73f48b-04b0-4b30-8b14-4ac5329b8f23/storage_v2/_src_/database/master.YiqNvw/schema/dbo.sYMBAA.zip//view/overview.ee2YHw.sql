create view overview (newspaper_id, newspaper_name, subscriber_id, subscriber_name, numbers)
as select subscription.newspaper_id as newspaper_id, newspaper.newspaper_name as newspaper_name, subscription.subscriber_id as subscriber_id, subscriber.subscriber_name as subscriber_name, subscription.numbers as numbers from newspaper, subscriber, subscription where subscription.subscriber_id = subscriber.subscriber_id and subscription.newspaper_id = newspaper.newspaper_id;
go

